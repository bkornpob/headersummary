# mag2flux
mag2flux converts AB magnitude to flux density (erg cm-2 s-1).
