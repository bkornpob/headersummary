# HeaderSummary
HeaderSummary does retrieving information from fits files' headers. path_list provides the search paths applied by glob.glob(). For each file, astropy.io.fits.open() is used to open the file. Header info is retrieved as specified in keywords.
